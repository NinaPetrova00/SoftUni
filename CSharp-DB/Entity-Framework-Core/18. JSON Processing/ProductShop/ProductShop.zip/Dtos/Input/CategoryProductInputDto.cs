﻿namespace ProductShop.Dtos.Input
{
    public class CategoryProductInputDto
    {
        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }
}
