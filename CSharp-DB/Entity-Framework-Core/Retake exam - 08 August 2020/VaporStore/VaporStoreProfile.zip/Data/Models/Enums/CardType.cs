﻿namespace VaporStore.Data.Models.Enums
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public enum CardType
    {
        Debit = 0,
        Credit = 1,
    }
}
