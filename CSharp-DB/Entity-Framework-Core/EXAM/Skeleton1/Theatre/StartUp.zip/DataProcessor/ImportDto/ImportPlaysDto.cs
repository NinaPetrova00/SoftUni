﻿namespace Theatre.DataProcessor.ImportDto
{
    using System.ComponentModel.DataAnnotations;
    using System.Xml.Serialization;
    using Theatre.Common;

    [XmlType("Play")]
    public class ImportPlaysDto
    {
        [XmlElement("Title")]
        [MinLength(GlobalConstants.PLAY_TITLE_MIN_LENGTH)]
        [MaxLength(GlobalConstants.PLAY_TITLE_MAX_LENGTH)]
        public string Title { get; set; }

        [XmlElement("Duration")]
        [MinLength(GlobalConstants.PLAY_DURATION_MIN_LENGTH)]
        public string Duration { get; set; }

        [XmlElement("Rating")]
        public double Rating { get; set; }

        [XmlElement("Genre")]
        [Range(GlobalConstants.PLAY_GENRE_MIN_VALUE, GlobalConstants.PLAY_GENRE_MAX_VALUE)]
        public int Genre { get; set; }

        [XmlElement("Description")]
        public string Description { get; set; }

        [XmlElement("Screenwriter")]
        [MinLength(GlobalConstants.PLAY_SCREENWRITER_MIN_LENGTH)]
        [MaxLength(GlobalConstants.PLAY_SCREENWRITER_MAX_LENGTH)]
        public string Screenwriter { get; set; }
    }
}
