﻿namespace Theatre.DataProcessor
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Theatre.Data;
    using Theatre.Data.Models;
    using Theatre.Data.Models.Enums;
    using Theatre.DataProcessor.ImportDto;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfulImportPlay
            = "Successfully imported {0} with genre {1} and a rating of {2}!";

        private const string SuccessfulImportActor
            = "Successfully imported actor {0} as a {1} character!";

        private const string SuccessfulImportTheatre
            = "Successfully imported theatre {0} with #{1} tickets!";

        public static string ImportPlays(TheatreContext context, string xmlString)
        {
            StringBuilder sb = new StringBuilder();

            XmlRootAttribute xmlRoot = new XmlRootAttribute("Plays");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportPlaysDto[]), xmlRoot);

            using StringReader stringReader = new StringReader(xmlString);

            ImportPlaysDto[] playsDtos = (ImportPlaysDto[])xmlSerializer.Deserialize(stringReader);

            HashSet<Play> plays = new HashSet<Play>();

            foreach (ImportPlaysDto playDto in playsDtos)
            {
                if (!IsValid(playDto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                bool isValidDuration = TimeSpan.TryParseExact(playDto.Duration, "c", CultureInfo.InvariantCulture, TimeSpanStyles.None, out TimeSpan duaration);

                if (!isValidDuration)
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                if (playDto.Rating < 0.0 && playDto.Rating > 10.0)
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                Play play = new Play()
                {
                    Title = playDto.Title,
                    Duration = duaration,
                    Rating = (float)playDto.Rating,
                    Genre = (Genre)playDto.Genre,
                    Description = playDto.Description,
                    Screenwriter = playDto.Screenwriter
                };
                plays.Add(play);
                sb.AppendLine(String.Format(SuccessfulImportPlay, play.Title, play.Genre, play.Rating));
            }
            context.Plays.AddRange(plays);
            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }

        public static string ImportCasts(TheatreContext context, string xmlString)
        {
            StringBuilder sb = new StringBuilder();

            XmlRootAttribute xmlRoot = new XmlRootAttribute("Casts");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportCastsDto[]), xmlRoot);

            using StringReader stringReader = new StringReader(xmlString);

            ImportCastsDto[] importCastsDtos = (ImportCastsDto[])xmlSerializer.Deserialize(stringReader);

            HashSet<Cast> casts = new HashSet<Cast>();
            foreach (ImportCastsDto importCastsDto in importCastsDtos)
            {
                if (!IsValid(importCastsDto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                Cast cast = new Cast()
                {
                    FullName = importCastsDto.FullName,
                    IsMainCharacter = importCastsDto.IsMainCharacter,
                    PhoneNumber = importCastsDto.PhoneNumber,
                    PlayId = importCastsDto.PlayId
                };
                casts.Add(cast);
                sb.AppendLine(String.Format(SuccessfulImportActor, importCastsDto.FullName, importCastsDto.IsMainCharacter));

            }
            context.Casts.AddRange(casts);
            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }

        public static string ImportTtheatersTickets(TheatreContext context, string jsonString)
        {
            StringBuilder sb = new StringBuilder();

            ImportTtheatersDto[] importTtheatersDtos =
                JsonConvert.DeserializeObject<ImportTtheatersDto[]>(jsonString);

            HashSet<Theatre> theatres = new HashSet<Theatre>();
            foreach (ImportTtheatersDto importTtheatersDto in importTtheatersDtos)
            {
                if (!IsValid(importTtheatersDto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                HashSet<Ticket> tickets = new HashSet<Ticket>();
                foreach (var ticket in importTtheatersDto.Tickets)
                {
                    Ticket ticketDto = new Ticket()
                    {
                        Price = ticket.Price,
                        RowNumber = ticket.RowNumber,
                        PlayId = ticket.PlayId
                    };
                    tickets.Add(ticketDto);
                }

                Theatre t = new Theatre()
                {
                    Name = importTtheatersDto.Name,
                    NumberOfHalls = (sbyte)importTtheatersDto.NumberOfHalls,
                    Director = importTtheatersDto.Director,
                    Tickets = tickets
                };
                theatres.Add(t);
                sb.AppendLine(String.Format(SuccessfulImportTheatre, t.Name, t.Tickets.Count()));
            }
            context.Theatres.AddRange(theatres);
            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }


        private static bool IsValid(object obj)
        {
            var validator = new ValidationContext(obj);
            var validationRes = new List<ValidationResult>();

            var result = Validator.TryValidateObject(obj, validator, validationRes, true);
            return result;
        }
    }
}
