﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=LAPTOP-Q2QM5415\SQLEXPRESS;Database=Theatre;Trusted_Connection=True";
    }
}
