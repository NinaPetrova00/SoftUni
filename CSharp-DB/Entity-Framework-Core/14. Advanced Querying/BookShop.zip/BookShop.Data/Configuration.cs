﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=LAPTOP-Q2QM5415\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
