﻿namespace P03_FootballBetting.Data.Models.Enumerations
{
    public enum Prediction
    {
        Home = 1,
        Draw = 0,
        Away = 2
    }
}
