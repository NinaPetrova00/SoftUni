﻿namespace P03_FootballBetting.Data
{
  public static class Configuration
    {
        public const string ConnectionString = @"Server=LAPTOP-Q2QM5415\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}

