﻿namespace TeisterMask.Common
{
    public static class GlobalConstants
    {
        //Employee
        public const int EMPLOYEE_USERNAME_MAX_LENGHT = 40;
        public const int EMPLOYEE_PHONE_MAX_LENGHT = 12;

        //Project
        public const int PROJECT_NAME_MAX_LENGHT = 40;

        //Task
        public const int Task_NAME_MAX_LENGHT = 40;
    }
}
