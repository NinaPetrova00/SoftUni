﻿namespace CarDealer.DTO.ImportDto
{
    using System.Xml.Serialization;

    [XmlType("Car")]
    public class ImportCarDto
    {
        [XmlElement("make")]
        public string Make { get; set; }

        [XmlElement("model")]
        public string Model { get; set; }

        [XmlElement("TraveledDistance")]
        public long TraveledDistance { get; set; }

        [XmlArray("parts")] //array of XmlTypes -> nested dtos
        public ImportCarPartDto[] Parts { get; set; }
    }
}
