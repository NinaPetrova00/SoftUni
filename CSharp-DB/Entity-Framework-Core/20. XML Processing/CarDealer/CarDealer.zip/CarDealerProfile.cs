﻿using AutoMapper;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            //TODO: Write your custom mappings here
        }
    }
}
