﻿namespace SoftJail.Data.Models.Enums
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public enum Weapon
    {
        Knife,
        FlashPulse,
        ChainRifle,
        Pistol,
        Sniper
    }
}
