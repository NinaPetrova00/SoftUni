﻿namespace SoftJail.Data.Models.Enums
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public enum Position
    {
        Overseer,
        Guard,
        Watcher,
        Labour
    }
}
