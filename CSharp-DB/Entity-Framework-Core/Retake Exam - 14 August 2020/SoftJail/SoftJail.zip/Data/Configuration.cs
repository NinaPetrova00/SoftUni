﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=LAPTOP-Q2QM5415\SQLEXPRESS;Database=SoftJail;Trusted_Connection=True";
    }
}
