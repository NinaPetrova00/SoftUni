﻿namespace CarRacing.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
